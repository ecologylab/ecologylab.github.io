package ecologylab.appframework.types.prefs;

public interface ValueChangedListener
{
    public void valueChanged(Pref pref);
}
