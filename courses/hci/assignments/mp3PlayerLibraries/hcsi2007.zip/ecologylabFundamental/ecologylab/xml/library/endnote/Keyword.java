/*
 * Created on Dec 12, 2006
 */
package ecologylab.xml.library.endnote;

import ecologylab.xml.ElementState;
import ecologylab.xml.xml_inherit;

/**
 * @author Zachary O. Toups (toupsz@cs.tamu.edu)
 */
public @xml_inherit class Keyword extends ElementState
{
    /**
     * 
     */
    public Keyword()
    {
    }
}
