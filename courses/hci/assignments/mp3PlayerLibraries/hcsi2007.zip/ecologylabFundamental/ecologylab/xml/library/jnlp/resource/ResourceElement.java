/**
 * 
 */
package ecologylab.xml.library.jnlp.resource;

import ecologylab.xml.ElementState;

/**
 * @author Zachary O. Toups (toupsz@cs.tamu.edu)
 *
 */
public class ResourceElement extends ElementState
{
    /**
     * 
     */
    public ResourceElement()
    {
        // TODO Auto-generated constructor stub
    }

}
