/**
 * 
 */
package ecologylab.xml.library.jnlp.resource;

/**
 * @author Zachary O. Toups (toupsz@cs.tamu.edu)
 *
 */
public class HrefBasedResource extends ResourceElement
{
    @xml_attribute private String href;

    /**
     * 
     */
    public HrefBasedResource()
    {
        super();
    }

}
