/*
 * Created on Dec 12, 2006
 */
package ecologylab.xml.library.endnote;

import ecologylab.xml.xml_inherit;
import ecologylab.xml.types.element.ArrayListState;

public @xml_inherit class Records extends ArrayListState<Record>
{
 
    public Records()
    {
        
    }
}
