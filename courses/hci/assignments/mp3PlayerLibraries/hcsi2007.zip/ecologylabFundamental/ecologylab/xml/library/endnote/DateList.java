/*
 * Created on Dec 12, 2006
 */
package ecologylab.xml.library.endnote;

import ecologylab.xml.ElementState;
import ecologylab.xml.types.element.StringState;

/**
 * @author Zachary O. Toups (toupsz@cs.tamu.edu)
 */
public class DateList extends ElementState
{
    private @xml_nested StringState year;
    
//    private @xml_nested String pub-dates = "";
    
    /**
     * 
     */
    public DateList()
    {
        // TODO Auto-generated constructor stub
    }
}
