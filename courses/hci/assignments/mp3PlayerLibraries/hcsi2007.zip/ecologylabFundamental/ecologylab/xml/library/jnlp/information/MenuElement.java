/**
 * 
 */
package ecologylab.xml.library.jnlp.information;

import ecologylab.xml.ElementState;

/**
 * @author Zachary O. Toups (toupsz@cs.tamu.edu)
 *
 */
public class MenuElement extends ElementState
{
    @xml_attribute private String submenu;

    /**
     * 
     */
    public MenuElement()
    {
        super();
    }
}
