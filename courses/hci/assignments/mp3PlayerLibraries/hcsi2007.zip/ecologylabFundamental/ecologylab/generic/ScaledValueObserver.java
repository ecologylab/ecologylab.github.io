/*
 * Created on Sep 28, 2005
 * 
 */
package ecologylab.generic;

import java.util.Observer;

/**
 * @author Andrew Webb
 *
 */
public interface ScaledValueObserver extends Observer 
{
	public short getScaledValue();
}
