package ecologylab.generic;

import ecologylab.xml.TranslationScope;

public interface StudyContext 
{
	public TranslationScope getTranslationSpace();
}
