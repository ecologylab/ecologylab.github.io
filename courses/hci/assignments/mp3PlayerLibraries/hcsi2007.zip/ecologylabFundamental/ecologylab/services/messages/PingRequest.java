package ecologylab.services.messages;

import ecologylab.xml.xml_inherit;

public @xml_inherit class PingRequest extends HttpRequest 
{
}
