package ecologylab.services.distributed.client;

public interface ReconnectBlocker
{
	public void reconnectBlock();
}
