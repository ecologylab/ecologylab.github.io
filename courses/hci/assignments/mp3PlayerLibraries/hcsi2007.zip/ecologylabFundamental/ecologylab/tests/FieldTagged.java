/**
 * 
 */
package ecologylab.tests;

import ecologylab.xml.ElementState;

/**
 * @author Zachary O. Toups (toupsz@cs.tamu.edu)
 *
 */
public class FieldTagged extends ElementState
{
	@xml_attribute int x = 37;
    /**
     * 
     */
    public FieldTagged()
    {
        // TODO Auto-generated constructor stub
    }

}
