package ecologylab.example.demos2d;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Stroke;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JFrame;

/**
 * Draw shapes, strokes, and fills.
 * 
 * @author andruid
 */
public class ShapesDemo extends JFrame
{
	// graphical objects
	Rectangle2D				square;

	Ellipse2D				circle;

	Stroke					stroke				= new BasicStroke(3);

	GradientPaint			gradient;

	// GUI state
	final int				frameSize			= 500;

	Insets					insets;

	int						squareSize			= frameSize / 6;

	// program state
	boolean					init					= true;

	boolean					isApplet				= false;

	/**
	 * Runs the animation loop in a thread-safe way.
	 */
	javax.swing.Timer		swingTimer;

	// rendering colors
	static final int		MIN_R					= 35;

	static final int		MIN_G					= 61;

	static final int		MIN_B					= 92;

	static final int		MAX_R					= 131;

	static final int		MAX_G					= 192;

	static final int		MAX_B					= 128;

	static final Color	RICH_BLUE			= new Color(35, 61, 92);

	static final Color	REFLECTION_COLOR	= new Color(131, 192, 128);

	public ShapesDemo()
	{
		this.setSize(frameSize, frameSize);
		int translation = frameSize / 4;

		square = new Rectangle2D.Double(translation, translation, squareSize,
				squareSize);
		circle = new Ellipse2D.Double(translation, translation, squareSize,
				squareSize);

		int origin = translation;
		int farCorner = translation + squareSize;

		gradient = new GradientPaint(origin, origin, REFLECTION_COLOR, farCorner,
				farCorner, RICH_BLUE, false);

		// stop the animation timer, if necessary, on window closing event
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				if (!isApplet)
				{
					dispose(); // release native resources used by Window & kids
					System.exit(0); // stop the JVM
				}
			}
		});
		// setDoubleBuffered(true);
	}

	public void paint(Graphics g)
	{
		super.paint(g);
		if (init)
		{
			init = false;
			int currentHeight = getHeight();
			insets = getInsets();

			System.out.println("currentHeight=" + currentHeight);
			setSize(frameSize + insets.left + insets.right, frameSize + insets.top
					+ insets.bottom);

			repaint();
		}
		else
		{
			Graphics2D g2 = (Graphics2D) g;
			// save the parent space
			AffineTransform parentSpace = g2.getTransform();

			// account for insets (e.g., title bar & other borders)
			g2.translate(insets.left, insets.top);

			g2.setPaint(REFLECTION_COLOR);
			g2.fill(square);
			g2.setColor(RICH_BLUE);
			g2.setStroke(stroke);
			g2.draw(square);

			// use temporaries for repeatedly used values!
			double squareWidth = square.getWidth();
			double moveOver = squareWidth * 1.5;
			g2.translate(moveOver, 0);

			g2.setPaint(this.gradient);
			g2.fill(square);

			AffineTransform beforeRotation = g2.getTransform();

			double halfHypotenuse = squareWidth * Math.sqrt(2) / 2;
			// move down
			g2.translate(squareWidth / 2, moveOver - halfHypotenuse);
			g2.rotate(45 * Math.PI / 180);
			g2.fill(square);

			g2.setTransform(beforeRotation);
			g2.translate(0, moveOver);
			g2.fill(circle);
			g2.setColor(RICH_BLUE);
			g2.setStroke(stroke);
			g2.draw(circle);

			// restore parent space
			g2.setTransform(parentSpace);
		}
	}

	public static void main(String[] args)
	{
		ShapesDemo spaceDemo = new ShapesDemo();
		spaceDemo.setVisible(true);
		spaceDemo.repaint();
	}
}
