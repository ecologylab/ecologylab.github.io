package ecologylab.example.simplegui.blueman;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * @author Administrator
 * 
 *         To change this generated comment edit the template variable
 *         "typecomment": Window>Preferences>Java>Templates. To enable and
 *         disable the creation of type comments go to
 *         Window>Preferences>Java>Code Generation.
 */
public class WavingMan extends JPanel
{

	BufferedImage		img		= null;

	AnimationSequence	waving	= null;

	AnimationSequence	walkleft	= null;

	AnimationSequence	turnleft	= null;

	public WavingMan()
	{
		this.setPreferredSize(new Dimension(400, 400));

		waving = new AnimationSequence(8, true);
		walkleft = new AnimationSequence(8, true);
		turnleft = new AnimationSequence(32, true);
	}

	public void init()
	{

		// load the images.. for the animation sequence
		BufferedImage images[] = new BufferedImage[7];

		// read in the image files
		try
		{
			images[0] = ImageIO.read(new File("images/animation/stand.jpg"));
			images[1] = ImageIO.read(new File("images/animation/standleft1.jpg"));
			images[2] = ImageIO.read(new File("images/animation/turnleft0.jpg"));
			images[3] = ImageIO.read(new File("images/animation/walkleft1.jpg"));
			images[4] = ImageIO.read(new File("images/animation/walkleft2.jpg"));
			images[5] = ImageIO.read(new File("images/animation/wave0.jpg"));
			images[6] = ImageIO.read(new File("images/animation/wave1.jpg"));
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		// add the images to the wave sequence

		waving.addImage(images[0]);
		waving.addImage(images[5]);
		waving.addImage(images[6]);
		waving.addImage(images[5]);

		// add the images to the turn left sequence

		turnleft.addImage(images[0]);
		turnleft.addImage(images[2]);
		turnleft.addImage(images[1]);
		turnleft.addImage(images[1]);

		// add the images to the walk left sequqnce

		walkleft.addImage(images[1]);
		walkleft.addImage(images[3]);
		walkleft.addImage(images[4]);
		walkleft.addImage(images[3]);

	}

	public void paint(Graphics g)
	{
		Graphics2D g2 = (Graphics2D) g;

		if (waving.getState() == AnimationSequenceStates.IDLE)
		{
			waving.start();
			turnleft.start();
			walkleft.start();
		}
		if (waving.getState() == AnimationSequenceStates.STARTED)
		{

			BufferedImage wavingFrame = waving.getNextFrame();
			BufferedImage walkleftFrame = walkleft.getNextFrame();
			BufferedImage turnleftFrame = turnleft.getNextFrame();
			// System.out.println("getting next frame");
			g2.drawImage(wavingFrame, 20, 20, this);
			g2.drawImage(walkleftFrame, 80, 20, this);
			g2.drawImage(turnleftFrame, 120, 20, this);
		}

		try
		{
			Thread.currentThread().sleep(40);
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		this.repaint();

	}

	public static void main(String[] args)
	{
		JFrame jf = new JFrame();
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		WavingMan wm = new WavingMan();
		wm.init();

		jf.getContentPane().add(wm);
		jf.pack();
		jf.setVisible(true);
	}
}
