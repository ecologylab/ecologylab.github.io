package ecologylab.example.simplegui.blueman;

import java.util.HashMap;
import java.util.Vector;

/**
 * @author Daniel J. Caruso
 * 
 *         Simple class which represents a node in a state machine Inputs are
 *         unique strings.. which are used as keys to retrive the name of the
 *         next state from the edgelist
 * 
 *         This is implimented with HasMap's and is not thread safe but is very
 *         fast
 */
public class AnimState
{
	// list of sdges keys bye input strings
	private HashMap	edgelist	= new HashMap();

	// a data object associated with this state
	private Object		dataobj	= null;

	// the name of the state
	private String		stateKey	= null;

	public AnimState(String key)
	{
		this.stateKey = key;
	}

	public void setData(Object obj)
	{
		this.dataobj = obj;
	}

	public Object getData()
	{
		return this.dataobj;
	}

	public String getStateKey()
	{
		return this.stateKey;
	}

	public void addEdge(String stateKey, String input)
	{
		edgelist.put(input, stateKey);
	}

	/**
	 * Method getNextStateKey. Return the name of the next state given an input
	 * string
	 * 
	 * @param input
	 * @return String
	 */
	public String getNextStateKey(String input)
	{
		return (String) edgelist.get(input);
	}

}
