/**
 * 
 */
package ecologylab.example;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author Zachary O. Toups (toupsz@ecologylab.net)
 *
 */
public class HelloLogger implements ActionListener
{

	/**
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e)
	{
		System.out.println(e.getActionCommand());
	}

}
