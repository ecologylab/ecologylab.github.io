package ecologylab.example.demos2d;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

/**
 * draw some shapes, with transforms.
 * 
 * @author dcaruso, andruid
 */
public class SpaceShip
{

	private int		xloc, yloc, width, height;

	private double	heading;

	Color				color;

	public SpaceShip(int xloc, int yloc, int width, int height, double heading,
			Color color)
	{
		this.xloc = xloc;
		this.yloc = yloc;
		this.width = width;
		this.height = height;
		this.heading = heading;
		this.color = color;
	}

	public void paint(Graphics2D g2)
	{
		AffineTransform transform = g2.getTransform();
		// transform to object space
		g2.translate(xloc, yloc);
		g2.rotate(heading * Math.PI / 180);
		// g2.setColor(Color.yellow);
		// g2.fillRect(0,0, width, height);
		g2.setColor(color);

		drawShip(g2);

		g2.setTransform(transform);
	}

	private void drawShip(Graphics2D g2)
	{
		// now create the ship as if we are starting at 0,0
		g2.drawRect(-width / 6 / 2, 0, width / 6, height);
		// draw the right wing
		g2.drawRect((width / 6) / 2, 0, width / 3, height / 2);
		// draw the left wing
		g2.drawRect((-(width / 6) / 2 - (width / 3)), 0, width / 3, height / 2);

	}

	public void incrementHeading(double increment)
	{
		double heading = this.heading;
		heading = (heading + increment) % 360.0;
		// System.out.println("heading="+heading);
		this.heading = heading;
	}
}
