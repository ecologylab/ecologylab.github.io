/**
 * 
 */
package ecologylab.standalone;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

import org.jaudiotagger.audio.exceptions.CannotReadException;
import org.jaudiotagger.audio.exceptions.InvalidAudioFrameException;
import org.jaudiotagger.audio.exceptions.ReadOnlyFileException;
import org.jaudiotagger.tag.TagException;

import ecologylab.media.AudioPlayer;
import ecologylab.xml.library.audiometadata.AudioFileMetadata;
import ecologylab.xml.library.audiometadata.AudioFileMetadataLibrary;

/**
 * @author Zach
 * 
 */
public class PlayASong
{

	/**
	 * @param args
	 * @throws IOException
	 * @throws UnsupportedAudioFileException
	 * @throws ClassCastException
	 * @throws LineUnavailableException
	 * @throws InvalidAudioFrameException 
	 * @throws ReadOnlyFileException 
	 * @throws TagException 
	 * @throws CannotReadException 
	 */
	public static void main(String[] args) throws IOException, ClassCastException,
			UnsupportedAudioFileException, LineUnavailableException, CannotReadException, TagException, ReadOnlyFileException, InvalidAudioFrameException
	{
		File mp3Dir = new File("./mp3s/");
		System.out.println("searching: " + mp3Dir.getCanonicalPath());

		System.out.println(mp3Dir);

		AudioFileMetadataLibrary lib = new AudioFileMetadataLibrary();

		for (File f : mp3Dir.listFiles())
		{
			String filename = f.getName();
			String extension = filename.substring(f.getName().lastIndexOf('.') + 1);

			if ("mp3".equals(extension))
			{
				System.out.println("reading file: " + f);

				lib.add(new AudioFileMetadata(f));
			}
			else
			{
				System.out.println("skipping file: " + f);
				System.out.println("because extension was " + extension);
			}
		}

		System.out.println("gonna try to play:");

		for (String s : lib.keySet())
		{
			Map<String, Object> props = lib.get(s).getPropertiesMap();

			System.out.println("---------> " + s);

			for (String s2 : props.keySet())
			{
				System.out.println(s2 + ": " + props.get(s2));
			}
		}

		AudioPlayer p = AudioPlayer.getAudioPlayerInstance();

		System.out.println(lib.keySet().toString());

		AudioFileMetadata aFM = lib.get(lib.keySet().iterator().next());

		System.out.println("AFM: " + aFM.toString());

		p.setAudioFile(aFM);

		p.playbackAudioFile();

		System.out.println("done");
	}
}
