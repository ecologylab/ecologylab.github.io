package ecologylab.example.simplegui;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.ConvolveOp;
import java.awt.image.ImageObserver;
import java.awt.image.Kernel;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * @author Daniel J. Caruso
 * 
 */
public class BasicImages  extends JPanel
{
	
	private ImageIcon ico = null;
	BufferedImage img = null;
	BufferedImage img2 = null;

	public BasicImages()
	{	
		setPreferredSize(new Dimension(640,480));	
		
		URL url = null;
		try
		{
			url = new URL("http://www.google.com/images/logo.gif");
		}
		catch (MalformedURLException e)
		{
			e.printStackTrace();
		}
																 
		try
		{
			img  = ImageIO.read(url);
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
											
	}
	

		
	public void paint(Graphics g)
	{
		
		Graphics2D g2 = (Graphics2D) g;
					 	

		float[] elements = { .06f, .06f, .06f, .06f,
							 .06f, .06f, .06f, .06f,
        	                 .06f, .06f, .06f, .06f,
           	         	 .06f, .06f, .06f, .06f}; 
                    
	
		Kernel kernel = new Kernel(4, 4, elements); 
		ConvolveOp cop = new ConvolveOp(kernel, ConvolveOp.EDGE_NO_OP, null);
		cop.filter(img,img2); 
		
		int x = 0;
		int y =0;
		ImageObserver obs = this;
				
		g2.drawImage(img2, x, y, obs);
		g2.drawImage(img, x, 150, obs);
				
	}
	
	
	public static void main(String[] args)
	{
		JFrame jf = new JFrame();
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		BasicImages stuff = new BasicImages();
		
		jf.getContentPane().add(stuff);
		jf.pack();
		jf.setVisible(true);		
	}

}
