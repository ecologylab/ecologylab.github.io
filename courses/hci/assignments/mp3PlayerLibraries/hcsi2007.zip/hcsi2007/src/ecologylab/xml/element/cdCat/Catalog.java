/**
 * 
 */
package ecologylab.xml.element.cdCat;

import java.io.File;

import ecologylab.xml.ElementState;
import ecologylab.xml.TranslationScope;
import ecologylab.xml.XMLTranslationException;
import ecologylab.xml.xml_inherit;
import ecologylab.xml.ElementState.xml_tag;
import ecologylab.xml.types.element.ArrayListState;

/**
 * @author toupsz
 *
 */
public @xml_tag("CATALOG") @xml_inherit class Catalog extends ArrayListState<Cd>
{
    /**
     * 
     */
    public Catalog()
    {
        super();
    }

    public static void main(String[] args) throws XMLTranslationException
    {
        File f = new File("./studentXMLExamples/bahratKumar.xml");

        final String NAME = "catalog";

        final Class TRANSLATIONS[] =
        { Cd.class, Catalog.class };

        TranslationScope ts = TranslationScope.get(NAME, TRANSLATIONS);
        
        Catalog c = (Catalog) ElementState.translateFromXML(f, ts);
        
        System.out.println(c.translateToXML());
    }
}
