/**
 * 
 */
package ecologylab.xml.element.rss;

import ecologylab.xml.ElementState;
import ecologylab.xml.ElementState.xml_attribute;
import ecologylab.xml.ElementState.xml_tag;
import ecologylab.xml.library.rss.Channel;
import ecologylab.xml.types.element.ArrayListState;

/**
 * @author toupsz
 *
 */
public class Rss extends ArrayListState<Channel>
{

    /**
     * 
     */
    public Rss()
    {
        super();
    }

    private @xml_attribute String version;
    private @xml_attribute @xml_tag("xmlns:dc") String xmlnsDc;

}
