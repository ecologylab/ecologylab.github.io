/**
 * 
 */
package ecologylab.standalone;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

import org.jaudiotagger.audio.exceptions.CannotReadException;
import org.jaudiotagger.audio.exceptions.InvalidAudioFrameException;
import org.jaudiotagger.audio.exceptions.ReadOnlyFileException;
import org.jaudiotagger.tag.TagException;

import ecologylab.media.AudioPlayer;
import ecologylab.xml.XMLTranslationException;
import ecologylab.xml.library.audiometadata.AudioFileMetadata;
import ecologylab.xml.library.audiometadata.AudioFileMetadataLibrary;
import ecologylab.xml.library.audiometadata.AudioFileMetadataList;
import ecologylab.xml.types.element.StringState;

/**
 * This is a simple example program that can play some MP3s (note that not all MP3s are compatible, unfortunately).
 * 
 * It is annotated throughout to give the reader an idea of the process of making an MP3 library and then selecting and
 * playing songs.
 * 
 * This is a quickly-thrown together application, you should NOT use static variables as is done here.
 * 
 * @author Zach
 * 
 */
public class TestAudioApp
{
    // instantiate a library object
    public static AudioFileMetadataLibrary lib  = new AudioFileMetadataLibrary();

    // instantiate a list object -- this is not absolutely necessary, but the list could be used for a playlist; in our
    // case, it is being used to get at the songs by a number, instead of their ID
    public static AudioFileMetadataList    list = new AudioFileMetadataList("everything playlist");

    // allocate an AudioPlayer -- we will instantiate it later, since it might throw exceptions
    public static AudioPlayer              player;

    /**
     * @param args
     * @throws IOException
     * @throws XmlTranslationException
     * @throws LineUnavailableException
     * @throws UnsupportedAudioFileException
     * @throws XMLTranslationException 
     * @throws InvalidAudioFrameException 
     * @throws ReadOnlyFileException 
     * @throws TagException 
     * @throws CannotReadException 
     */
    public static void main(String[] args) throws IOException, LineUnavailableException,
            UnsupportedAudioFileException, XMLTranslationException, CannotReadException, TagException, ReadOnlyFileException, InvalidAudioFrameException
    {
        // we instantiate the audio player here. if this method fails, you may have to try the alternative factory
        // method provided by AudioPlayer -- you can manually specify which mixer and line you wish to use
        player = AudioPlayer.getAudioPlayerInstance();

        // we load all the songs in the ./mp3s directory into the library and the list at the same time (see the method
        // for more details)
        setupLibrary();

        boolean running = true;

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        while (running)
        {
            System.out.println();
            System.out.println("Select an option: ");
            System.out.println(" (1) show song files (in ./mp3s)");
            System.out.println(" (2) show XML of song file metadata (in ./mp3s)");
            System.out.println(" (3) play a song...");
            System.out.println(" (q) quit");

            char userResponse = br.readLine().charAt(0);

            switch (userResponse)
            {
            case ('q'):
            case ('Q'):
                running = false;
                break;
            case ('1'):
                // list songs displays some of the metadata for each of the songs in list in the order they are stored
                listSongs();
                break;
            case ('2'):
                // creates a pretty XML file (./mp3s/lib.xml) and prints it to the screen
                printXML();
                break;
            case ('3'):
                System.out.println("choose a song:");

                // as before, lists the songs
                listSongs();

                // get the user input -- if it's not a number, this program will crash :(
                int songResponse = Integer.parseInt(br.readLine());

                // we then retrieve a StringState object (a wrapper for a String) from the list, based on the number the
                // user entered, this is the ID in the library of the song
                String songToPlayId = list.get(songResponse).string;

                // we then get the associated AudioFileMetadata object from the library, using the ID
                AudioFileMetadata songToPlay = lib.get(songToPlayId);

                System.out.println("attempting to play " + songToPlay.getTitle());

                // we tell the player that this is the song we want to manipulate
                player.setAudioFile(songToPlay);

                // we tell the player to play
                player.playbackAudioFile();

                // note that now the program is not responsive while it plays; this is because this application is
                // single-threaded, and thus cannot control the audio stream (because the audio is playing on the only
                // thread available)
                // in your application, you will need to modify the playbackAudioFile method so that it regularly checks
                // some variable that will be modified by another thread; this will enable you to pause and stop the
                // audio stream

                break;
            }

        }
    }

    /**
     * @throws XmlTranslationException
     * @throws IOException
    * @throws XMLTranslationException 
     * 
     */
    private static void printXML() throws IOException, XMLTranslationException
    {
        File f = new File("./mp3s/lib.xml");

        // this translates lib into XML and saves it in a file; you may also want to use the method translateToXML(),
        // this will just give you a one-line String of all the XML instead of a well-formatted file.
        lib.writePrettyXML(f);

        FileInputStream in = new FileInputStream(f);
        byte bt[] = new byte[(int) f.length()];

        in.read(bt);

        System.out.println(new String(bt));
    }

    /**
     * 
     */
    private static void listSongs()
    {
        int i = 0;

        // we take the list of song IDs that are in list and iterate over them all
        for (StringState s : list)
        {
            // for each one, we retrieve the associated metadata from lib using the ID as a key
            AudioFileMetadata a = lib.get(s.string);

            // we then simply print out some of the data in the metadata object
            System.out.print("(" + i + ") ");
            System.out.print("\"" + a.getTitle() + "\"");
            System.out.print(" by " + a.getArtist());
            System.out.println(" on album " + a.getAlbum());

            i++;
        }
    }

    /**
     * @throws IOException
     * @throws InvalidAudioFrameException 
     * @throws ReadOnlyFileException 
     * @throws TagException 
     * @throws CannotReadException 
     * 
     */
    private static void setupLibrary() throws IOException, CannotReadException, TagException, ReadOnlyFileException, InvalidAudioFrameException
    {
        File mp3Dir = new File("./mp3s/");

        // to be complete, we add our list object to the lib object. You can add any number of lists to an
        // AudioFileMetadataLibrary object, and they can be used to represent playlists.
        lib.addList(list);

        // we then iterate over each file in the ./mp3s directory...
        for (File f : mp3Dir.listFiles())
        {
            String filename = f.getName();
            String extension = filename.substring(f.getName().lastIndexOf('.') + 1);

            // ...we only consider the ones that end in ".mp3"
            if ("mp3".equals(extension))
            {
                try
                {
                    // we create an AudioFileMetadata object around the MP3; if this step fails, it was probably not
                    // really an MP3 file
                    AudioFileMetadata a = new AudioFileMetadata(f);

                    // once we have the object, we add it to lib
                    lib.add(a);

                    // since list is just a list of every song in lib, we add it to list as well; you don't have to do
                    // this...you might have a variety of playlists
                    list.add(a);
                }
                catch (ClassCastException e)
                {
                    e.printStackTrace();
                }
                catch (UnsupportedAudioFileException e)
                {
                    e.printStackTrace();
                }
            }
        }
    }
}
