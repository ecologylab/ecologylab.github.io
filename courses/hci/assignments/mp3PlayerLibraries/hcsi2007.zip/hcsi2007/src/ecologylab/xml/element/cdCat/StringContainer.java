package ecologylab.xml.element.cdCat;

import ecologylab.xml.ElementState;

public class StringContainer extends ElementState
{
    @xml_leaf private String s;
    
    public StringContainer()
    {
        super();
    }

    public StringContainer(String s)
    {
        this.s = s;
        
        System.out.println(s);
    }
}
