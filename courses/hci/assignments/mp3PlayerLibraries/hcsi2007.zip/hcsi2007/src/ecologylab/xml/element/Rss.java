package ecologylab.xml.element;

public class Rss
{

}
