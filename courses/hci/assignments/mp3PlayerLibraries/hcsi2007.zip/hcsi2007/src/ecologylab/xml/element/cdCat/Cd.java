/**
 * 
 */
package ecologylab.xml.element.cdCat;

import ecologylab.xml.ElementState;
import ecologylab.xml.xml_inherit;
import ecologylab.xml.ElementState.xml_tag;

/**
 * @author toupsz
 * 
 */
public @xml_tag("CD") @xml_inherit class Cd extends ElementState
{

    private @xml_leaf @xml_tag("TITLE") String title;
    private @xml_leaf @xml_tag("ARTIST") String artist;
    private @xml_leaf @xml_tag("COUNTRY") String country;
    private @xml_leaf @xml_tag("COMPANY") String company;
    private @xml_leaf @xml_tag("PRICE") String price;
    private @xml_leaf @xml_tag("YEAR") String year;
    
    /**
     * 
     */
    public Cd()
    {
        super();
    }

   
}
