package ecologylab.example.demos2d;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;

public class AnimatedShape
{
	protected Shape	shape;

	protected Paint	paint;

	protected Stroke	stroke;

	protected double	rotation;

	protected double	x, y;

	public AnimatedShape(Shape shape, Paint paint, Stroke stroke, double x,
			double y, double rotation)
	{
		this.shape = shape;
		this.paint = paint;
		this.stroke = stroke;
		this.rotation = rotation;
		this.x = x;
		this.y = y;
	}

	public AnimatedShape(Shape shape, Paint paint, double x, double y)
	{
		this(shape, paint, null, x, y, 0);
	}

	public void paint(Graphics2D g2)
	{
		// System.out.println("AnimatedShape.paint()");

		// transform to object space
		g2.translate(x, y);
		g2.rotate(rotation * Math.PI / 180);

		if (paint != null)
		{
			g2.setPaint(paint);
			g2.fill(shape);
		}
		if (stroke != null)
		{
			g2.setStroke(stroke);
			g2.draw(shape);
		}
	}

	/**
	 * Method to be overridden by subclasses, in order to change state for
	 * animation. Could be defined as abstract if we want to insist that all
	 * shapes are animated. Providing an empty implementation enables using this
	 * class for non-animated Shapes, too.
	 * 
	 */
	public void nextFrame()
	{
	}

	/**
	 * @param paint
	 *           The paint to set.
	 */
	public void setPaint(Paint paint)
	{
		this.paint = paint;
	}

	/**
	 * @param stroke
	 *           The stroke to set.
	 */
	public void setStroke(Stroke stroke)
	{
		this.stroke = stroke;
	}

}
