package ecologylab.example.simplegui.blueman;

import java.awt.image.BufferedImage;
import java.util.Vector;

/**
 * @author Daniel J. Caruso
 * 
 *         Simple class which represents an animation sequence
 * 
 */
public class AnimationSequence
{
	private Vector		frames	= new Vector();	// each rendered framein this
																// sequence

	private int			sequenceSteps;				// maximum number of frames in
																// the cycle

	private int			currentStep;					// the current frame

	private int			state;							// current state either.. IDLE,
																// STARTED, PAUSED, or FINISHED

	private boolean	loop		= false;			// does the animation loop
																// indefinantly

	public AnimationSequence(int numSteps, boolean loop)
	{
		this.sequenceSteps = numSteps;
		this.loop = loop;

		this.state = AnimationSequenceStates.IDLE;
	}

	public void addImage(BufferedImage img)
	{
		frames.add(img);
	}

	public void replaceImage(BufferedImage img, int frameIndex)
	{
		frames.setElementAt(img, frameIndex);
	}

	public BufferedImage getNextFrame()
	{

		if (this.state != AnimationSequenceStates.STARTED)
			return (BufferedImage) this.frames.elementAt(0);
		if (currentStep > sequenceSteps && this.loop == false)
		{
			this.state = AnimationSequenceStates.FINISHED;
			return (BufferedImage) this.frames.lastElement();
		}
		else if (currentStep > sequenceSteps && this.loop == true)
		{
			currentStep = 0;
		}

		// ok get the current frame...

		int index = (int) (this.currentStep * (this.frames.size() / ((float) this.sequenceSteps)));
		if (index >= this.frames.size())
		{
			index = this.frames.size() - 1;
		}

		BufferedImage frame = (BufferedImage) this.frames.elementAt(index);

		currentStep++;

		return frame;

	}

	public void stop()
	{
		this.currentStep = 0;
		this.state = AnimationSequenceStates.IDLE;
	}

	public void start()
	{
		this.currentStep = 0;
		this.state = AnimationSequenceStates.STARTED;
	}

	public void pause()
	{
		this.state = AnimationSequenceStates.PAUSED;
	}

	public void resume()
	{
		this.state = AnimationSequenceStates.STARTED;
	}

	public int getState()
	{
		return this.state;
	}

}
