package ecologylab.example.simplegui.blueman;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * @author Administrator
 * 
 *         To change this generated comment edit the template variable
 *         "typecomment": Window>Preferences>Java>Templates. To enable and
 *         disable the creation of type comments go to
 *         Window>Preferences>Java>Code Generation.
 */
public class ComplexAnimation extends JPanel
{

	BufferedImage			images[]		= new BufferedImage[7];

	SimpleStateMachine	sm				= null;

	AnimationSequence		walkleft		= null;

	AnimationSequence		idle			= null;

	int						idlecount	= 0;

	int						leftcount	= 0;

	public ComplexAnimation()
	{
		this.setPreferredSize(new Dimension(100, 100));
	}

	public void init()
	{
		// load the images.. for the animation sequences

		// read in the image files
		try
		{
			images[0] = ImageIO.read(new File("images/animation/stand.jpg"));
			images[1] = ImageIO.read(new File("images/animation/standleft1.jpg"));
			images[2] = ImageIO.read(new File("images/animation/turnleft0.jpg"));
			images[3] = ImageIO.read(new File("images/animation/walkleft1.jpg"));
			images[4] = ImageIO.read(new File("images/animation/walkleft2.jpg"));
			images[5] = ImageIO.read(new File("images/animation/wave0.jpg"));
			images[6] = ImageIO.read(new File("images/animation/wave1.jpg"));
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		// create the animation sequences

		walkleft = new AnimationSequence(8, true);
		idle = new AnimationSequence(18, true);

		// set the image sequence

		idle.addImage(images[0]);
		idle.addImage(images[0]);
		idle.addImage(images[5]);
		idle.addImage(images[6]);
		idle.addImage(images[5]);
		idle.addImage(images[0]);
		idle.addImage(images[0]);

		walkleft.addImage(images[1]);
		walkleft.addImage(images[3]);
		walkleft.addImage(images[4]);
		walkleft.addImage(images[3]);

		// init state machine
		sm = new SimpleStateMachine();

		// create states and add the to the machine..
		AnimState s1 = new AnimState("idle");
		s1.setData(idle);
		sm.addState(s1, s1.getStateKey());

		AnimState s2 = new AnimState("walkleft");
		s2.setData(walkleft);
		sm.addState(s2, s2.getStateKey());

		// add tranistions

		sm.addEdge("idle", "walkleft", "left");
		sm.addEdge("idle", "idle", "idle");
		sm.addEdge("walkleft", "idle", "idle");

		// initilize the machine
		sm.setCurrentState(s1.getStateKey());

	}

	public void paint(Graphics g)
	{
		Graphics2D g2 = (Graphics2D) g;

		// simple code to drive transitions
		if (idlecount >= 100 && leftcount < 200)
		{
			sm.doTransition("left");
			leftcount++;
		}
		else
		{
			sm.doTransition("idle");
			idlecount++;
		}

		if (idlecount >= 100 && leftcount >= 200)
		{
			idlecount = 0;
			leftcount = 0;
		}

		AnimationSequence animseq = (AnimationSequence) sm.getCurrentState()
				.getData();

		if (animseq.getState() != AnimationSequenceStates.STARTED)
		{
			animseq.start();
		}

		BufferedImage img = animseq.getNextFrame();

		g2.drawImage(img, 40, 20, this);

		try
		{
			Thread.currentThread().sleep(40);
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		this.repaint();

	}

	public static void main(String[] args)
	{

		JFrame jf = new JFrame();
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		ComplexAnimation canim = new ComplexAnimation();

		canim.init();

		jf.getContentPane().add(canim);

		jf.pack();
		jf.setVisible(true);

	}
}
