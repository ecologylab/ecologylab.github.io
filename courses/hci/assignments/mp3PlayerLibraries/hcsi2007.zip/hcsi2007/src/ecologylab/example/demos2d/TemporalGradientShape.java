package ecologylab.example.demos2d;

import java.awt.Color;
import java.awt.Shape;

/**
 * A shape whose fill color is animated by flipping through a continuous set of
 * colors.
 * 
 * @author andruid
 */
public class TemporalGradientShape extends AnimatedShape
{
	/**
	 * Enough colors for 5 seconds of animation.
	 */
	int	numColors;

	Color	colorTable[];

	/**
	 * The color we're currently painting.
	 */
	int	colorIndex	= 0;

	/**
	 * The direction through which we're cycling through the color table. +1 or
	 * -1.
	 */
	int	sign			= 1;

	public TemporalGradientShape(Shape shape, Color startColor, Color endColor,
			int numColors, double x, double y)
	{
		super(shape, null, null, x, y, 0);
		this.numColors = numColors;
		colorTable = new Color[numColors];
		setupColorTable(startColor, endColor, numColors);
		setPaint(colorTable[colorIndex]);
	}

	protected void setupColorTable(Color startColor, Color endColor,
			int numColors)
	{
		// rendering colors
		final int startR = startColor.getRed();
		final int startG = startColor.getGreen();
		final int startB = startColor.getBlue();
		final int endR = endColor.getRed();
		final int endG = endColor.getGreen();
		final int endB = endColor.getBlue();

		final float deltaR = ((float) endR - (float) startR) / (float) numColors;
		final float deltaG = ((float) endG - (float) startG) / (float) numColors;
		final float deltaB = ((float) endB - (float) startB) / (float) numColors;

		//System.out.println("deltaR="+deltaR+" deltaG="+deltaG+" deltaB="+deltaB)
		// ;
		for (int i = 0; i < numColors; i++)
		{
			float r = startR + i * deltaR + .5f;
			float g = startG + i * deltaG + .5f;
			float b = startB + i * deltaB + .5f;
			// System.out.println(i+": "+ r +", "+g +", "+b);
			colorTable[i] = new Color((int) r, (int) g, (int) b);
		}
	}

	public void nextFrame()
	{
		// System.out.println("TemporalGradientShape.nextFrame()");

		// use temporaries on the stack for efficiency
		int colorIndex = this.colorIndex;
		colorIndex = (colorIndex + sign * 1);
		int animLength = colorTable.length;

		if (colorIndex >= animLength)
		{
			colorIndex = animLength - 1;
			sign = -1;
		}
		else if (colorIndex < 0)
		{
			colorIndex = 0;
			sign = 1;
		}
		this.colorIndex = colorIndex;
		setPaint(colorTable[colorIndex]);
	}

	/**
	 * Set the temporal position of the animation, in terms of traversing the
	 * color table.
	 * 
	 * @param position
	 *           A double on [0.0, 1.0]: 0 for the beginning, 1.0 for the end.
	 */
	public void setTemporalPosition(double position)
	{
		int newIndex = (int) (((double) colorTable.length) * position);
		System.out.println("setTemporalPosition(" + position + ") = " + newIndex);
		colorIndex = newIndex;
	}
}
