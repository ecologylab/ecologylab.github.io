/**
 * 
 */
package ecologylab.standalone;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import javax.sound.sampled.UnsupportedAudioFileException;

import org.jaudiotagger.audio.exceptions.CannotReadException;
import org.jaudiotagger.audio.exceptions.InvalidAudioFrameException;
import org.jaudiotagger.audio.exceptions.ReadOnlyFileException;
import org.jaudiotagger.tag.TagException;

import ecologylab.xml.XMLTranslationException;
import ecologylab.xml.library.audiometadata.AudioFileMetadata;
import ecologylab.xml.library.audiometadata.AudioFileMetadataLibrary;

/**
 * @author toupsz
 * 
 */
public class GenerateMP3Library
{

    /**
     * @param args
     * @throws IOException
     * @throws InvalidAudioFrameException
     * @throws ReadOnlyFileException
     * @throws TagException
     * @throws CannotReadException
     * @throws XmlTranslationException
     * @throws UnsupportedAudioFileException 
     * @throws XMLTranslationException 
     * @throws InvalidAudioFrameException 
     * @throws ReadOnlyFileException 
     * @throws TagException 
     * @throws CannotReadException 
     * @throws ClassCastException 
     * @throws ID3Exception
     */
    public static void main(String[] args) throws IOException, UnsupportedAudioFileException, XMLTranslationException, ClassCastException, CannotReadException, TagException, ReadOnlyFileException, InvalidAudioFrameException
    {
//        TDebug.TraceAudioFileReader = true;
        File mp3Dir = new File("./mp3s/");
        System.out.println("searching: " + mp3Dir.getCanonicalPath());

        System.out.println(mp3Dir);

        AudioFileMetadataLibrary lib = new AudioFileMetadataLibrary();

        for (File f : mp3Dir.listFiles())
        {
            String filename = f.getName();
            String extension = filename
                    .substring(f.getName().lastIndexOf('.') + 1);

            if ("mp3".equals(extension))
            {
                System.out.println("reading file: " + f);

                AudioFileMetadata newMD = new AudioFileMetadata(f);
                
                lib.add(newMD);
                
                Map<String, Object> props = newMD.getPropertiesMap();
                
                for (String s : props.keySet())
                {
                    System.out.println(s+": "+props.get(s));
                }
            }
            else
            {
                System.out.println("skipping file: " + f);
                System.out.println("because extension was " + extension);
            }
        }

        System.out.println(lib.translateToXML());
    }
}
