package ecologylab.example.simplegui;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * @author Daniel J. Caruso
 * 
 *         Simple Swing Application
 */
public class HelloApplication extends JFrame implements ActionListener
{

	private JLabel	label			= null;

	private int		numclicks	= 0;

	public HelloApplication()
	{
		JPanel pannel = new JPanel();
		JButton b = new JButton("Click Me!");
		label = new JLabel("Number of clicks : " + numclicks);

		pannel.add(b);
		pannel.add(label);

		b.addActionListener(this);

		this.getContentPane().add(pannel);
	}

	public void actionPerformed(ActionEvent e)
	{
		// only one possible event...
		numclicks++;
		label.setText("Number of clicks : " + numclicks);

	}

	/*
	 * public static void main(String args[]) { JFrame theframe = new
	 * HelloApplication(); theframe.pack(); theframe.setVisible(true); }
	 */

	public void main(String args[])
	{
		JFrame window = new JFrame();

		// window.getContentPane().add(b);

		window.pack();
		window.setVisible(true);

		JPanel panel = new JPanel();

		GridLayout glm = new GridLayout(4, 4);

		panel.setLayout(glm);
		panel.add(new JButton());
		panel.add(new JButton());
		panel.add(new JButton());

		JButton b = new JButton("blah");
		ImageIcon ico = new ImageIcon("myimage.jpg");
		b.setIcon(ico);

	}

}
