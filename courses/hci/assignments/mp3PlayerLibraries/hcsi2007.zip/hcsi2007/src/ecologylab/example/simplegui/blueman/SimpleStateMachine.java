package ecologylab.example.simplegui.blueman;

import java.util.HashMap;

/**
 * @author Daniel J. Caruso
 * 
 *         A simple state machine used for animation
 */
public class SimpleStateMachine
{

	private HashMap	states	= new HashMap();

	private AnimState	current	= null;

	public AnimState getCurrentState()
	{
		return current;
	}

	public boolean setCurrentState(String stateKey)
	{
		AnimState state = (AnimState) states.get(stateKey);
		if (state == null)
			return false;
		else
		{
			this.current = state;
			return true;
		}
	}

	public boolean doTransition(String input)
	{
		if (current == null)
			return false;

		AnimState target = (AnimState) states.get(current.getNextStateKey(input));
		if (target == null)
			return false;
		else
		{
			current = target;
			return true;
		}
	}

	public void addState(AnimState state, String stateKey)
	{
		states.put(stateKey, state);
	}

	public boolean addEdge(String stateKey1, String stateKey2, String input)
	{
		AnimState curr = (AnimState) states.get(stateKey1);
		AnimState target = (AnimState) states.get(stateKey2);

		if (curr == null || target == null)
			return false;
		else
		{
			curr.addEdge(target.getStateKey(), input);
			return true;
		}
	}

}
