package ecologylab.example.simplegui;

import java.awt.Graphics2D;

/**
 * @author Administrator
 * 
 *         To change this generated comment edit the template variable
 *         "typecomment": Window>Preferences>Java>Templates. To enable and
 *         disable the creation of type comments go to
 *         Window>Preferences>Java>Code Generation.
 */
public interface Sprite
{

	public void sendInput(String in);

	public void drawNext(Graphics2D g);

}
