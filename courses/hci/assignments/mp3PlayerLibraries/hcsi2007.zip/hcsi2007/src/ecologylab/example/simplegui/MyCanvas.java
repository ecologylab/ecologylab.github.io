package ecologylab.example.simplegui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Shape;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Rectangle2D;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class MyCanvas extends JPanel implements MouseListener,
		MouseMotionListener
{

	private Rectangle2D[]	rectlist	= new Rectangle2D[3];

	private Shape				selected	= null;

	public MyCanvas()
	{
		rectlist[0] = new Rectangle2D.Double(50.0, 50.0, 75.0, 25.0);
		rectlist[1] = new Rectangle2D.Double(10.0, 75.0, 20.0, 25.0);
		rectlist[2] = new Rectangle2D.Double(70.0, 100.0, 50.0, 35.0);
		
		this.setPreferredSize(new Dimension(200, 200));
		this.addMouseMotionListener(this);
		this.addMouseListener(this);
	}

	public void paint(Graphics g)
	{
		Graphics2D g2 = (Graphics2D) g;

		g2.clearRect(0, 0, this.getWidth(), this.getHeight());
		Color c1 = new Color(1.0f, 0.2f, 0.2f);
		Color c2 = new Color(0.0f, 1.0f, 0.0f);
		g2.setColor(c1);

		g2.draw(rectlist[0]);
		g2.fill(rectlist[1]);

		Point p1 = new Point((int) (rectlist[2].getCenterX() - (rectlist[2]
				.getWidth() / 2)), (int) (rectlist[2].getCenterY() - (rectlist[2]
				.getHeight() / 2)));
		Point p2 = new Point((int) (rectlist[2].getCenterX() + (rectlist[2]
				.getWidth() / 2)), (int) (rectlist[2].getCenterY() + (rectlist[2]
				.getHeight() / 2)));
		g2.setPaint(new GradientPaint(p1, c1, p2, c2));

		g2.fill(rectlist[2]);

	}

	public void mouseReleased(MouseEvent e)
	{
		selected = null;
	}

	public void mousePressed(MouseEvent e)
	{
		int x = e.getX();
		int y = e.getY();

		for (int i = 0; i < rectlist.length; i++)
		{

			if (rectlist[i].contains((double) x, (double) y))
			{
				selected = rectlist[i];
				break;
			}
		}
	}

	public void mouseDragged(MouseEvent e)
	{
		System.out.println("mousedraged " + e.getX() + ":" + e.getY());
		System.out.println(selected);
		if (selected != null)
		{
			if (selected instanceof Rectangle2D)
			{
				Rectangle2D rec = (Rectangle2D) selected;
				rec.setRect((double) e.getX(), (double) e.getY(), rec.getWidth(),
						rec.getHeight());
			}
		}
		repaint();
	}

	public void mouseClicked(MouseEvent e)
	{
	}

	public void mouseMoved(MouseEvent e)
	{
	}

	public void mouseExited(MouseEvent e)
	{

	}

	public void mouseEntered(MouseEvent e)
	{

	}

	public static void main(String args[])
	{
		JFrame jf = new JFrame();
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		jf.getContentPane().add(new MyCanvas());
		jf.pack();
		jf.setVisible(true);

	}

}
