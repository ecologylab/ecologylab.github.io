package ecologylab.example.simplegui;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

/**
 * @author Administrator
 * 
 *         To change this generated comment edit the template variable
 *         "typecomment": Window>Preferences>Java>Templates. To enable and
 *         disable the creation of type comments go to
 *         Window>Preferences>Java>Code Generation.
 */
public class BlueMan implements Sprite
{
	BufferedImage[]	images;

	private String[]	imagenames		=
												{ "stand.jpg", "wave0.jpg", "wave1.jpg" };

	private int[]		waveSequence	=
												{ 0, 1, 2, 1 };

	private int			state;

	private int			statecount		= 0;

	public void sendInput(String in)
	{
		images = new BufferedImage[7];
		state = 0;

	}

	public void drawNext(Graphics2D g)
	{
		statecount++;
		if (statecount >= 10)
		{
			statecount = 0;

		}
	}
}
