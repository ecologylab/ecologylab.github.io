/**
 * 
 */
package ecologylab.example;

import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * @author Zachary O. Toups (toupsz@ecologylab.net)
 * 
 */
public class HelloApplication extends JFrame implements ActionListener
{
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
		}
		catch (ClassNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (InstantiationException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IllegalAccessException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (UnsupportedLookAndFeelException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		final JFrame theFrame = new HelloApplication();

		javax.swing.SwingUtilities.invokeLater(new Runnable()
		{
			public void run()
			{
				initUI(theFrame);
			}
		});
	}

	private JLabel	label			= null;

	private int		numClicks	= 0;
	
	private final String UP_BUTTON = "UP";
	
	private final String DOWN_BUTTON = "DOWN";

	/**
	 * @throws HeadlessException
	 */
	public HelloApplication() throws HeadlessException
	{
		JPanel panel = new JPanel();

		JButton upButton = new JButton("up");
		upButton.setActionCommand(UP_BUTTON);
		panel.add(upButton);

		JButton downButton = new JButton("down");
		downButton.setActionCommand(DOWN_BUTTON);
		panel.add(downButton);
		
		label = new JLabel("Number of clicks: " + numClicks);
		panel.add(label);

		HelloLogger l = new HelloLogger();
		
		upButton.addActionListener(this);
		downButton.addActionListener(this);
		
		upButton.addActionListener(l);
		downButton.addActionListener(l);

		this.getContentPane().add(panel);
	}

	public void actionPerformed(ActionEvent e)
	{
		if (UP_BUTTON == e.getActionCommand())
		{
			numClicks++;
		}
		if (DOWN_BUTTON == e.getActionCommand())
		{
			numClicks--;
		}
		
		// only one possible event...
		javax.swing.SwingUtilities.invokeLater(new Runnable()
		{
			public void run()
			{
				updateUI();
			}
		});
	}

	/**
	 * Initializes the UI for the application. Should be called from the event
	 * dispatching thread.
	 * 
	 * @param theFrame
	 */
	private static void initUI(JFrame theFrame)
	{
		theFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		theFrame.getContentPane().setLayout(new GridLayout(0,2));
		theFrame.setSize(100, 30);
		theFrame.setVisible(true);
		theFrame.pack();
	}

	/**
	 * Updates the user interface. Should be called from the event dispatching
	 * thread.
	 */
	private void updateUI()
	{
		label.setText("Number of clicks: " + numClicks);

		// makes the label auto-resize
		this.pack();
	}
}
