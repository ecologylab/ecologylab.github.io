package ecologylab.example.simplegui.blueman;

/**
 * @author Daniel J. Caruso
 */
public interface AnimationSequenceStates
{

	static final int	IDLE		= 0;

	static final int	STARTED	= 1;

	static final int	PAUSED	= 2;

	static final int	FINISHED	= 3;

}
