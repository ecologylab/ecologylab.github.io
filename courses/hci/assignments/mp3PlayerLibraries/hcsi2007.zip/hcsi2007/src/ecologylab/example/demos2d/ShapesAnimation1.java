package ecologylab.example.demos2d;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Stroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;

import javax.swing.JComponent;
import javax.swing.JFrame;

/**
 * Draw shapes, strokes, and fills. Version 1, without object-oriented design.
 * 
 * @author andruid
 */
public class ShapesAnimation1 extends JFrame implements ActionListener
{
	// graphical objects
	Rectangle2D				square;

	Stroke					stroke					= new BasicStroke(3);

	GradientPaint			gradient;

	// GUI state
	final int				frameSize				= 500;

	Insets					insets;

	int						squareSize				= frameSize / 6;

	int						sign						= 1;

	// program state
	boolean					init						= true;

	boolean					isApplet					= false;

	/**
	 * Runs the animation loop in a thread-safe way.
	 */
	javax.swing.Timer		swingTimer;

	// rendering colors
	static final int		MIN_R						= 35;

	static final int		MIN_G						= 61;

	static final int		MIN_B						= 92;

	static final int		MAX_R						= 131;

	static final int		MAX_G						= 192;

	static final int		MAX_B						= 128;

	static final Color	RICH_BLUE				= new Color(35, 0, 92);

	static final Color	REFLECTION_COLOR		= new Color(131, 250, 128);

	/**
	 * Enough colors for 5 seconds of animation.
	 */
	static final int		NUM_COLORS				= 30 * 5;

	static final Color	BLUE_TO_RELFECTION[]	= new Color[NUM_COLORS];

	static
	{
		final float deltaR = ((float) MAX_R - (float) MIN_R) / (float) NUM_COLORS;
		final float deltaG = ((float) MAX_G - (float) MIN_G) / (float) NUM_COLORS;
		final float deltaB = ((float) MAX_B - (float) MIN_B) / (float) NUM_COLORS;
		System.out.println("deltaR=" + deltaR + " deltaG=" + deltaG);
		for (int i = 0; i < NUM_COLORS; i++)
		{
			float r = MIN_R + i * deltaR + .5f;
			float g = MIN_G + i * deltaG + .5f;
			float b = MIN_B + i * deltaB + .5f;
			// System.out.println(i+": "+ r +", "+
			// (MIN_G + i * deltaG) +", "+
			// (MIN_B + i * deltaB));
			BLUE_TO_RELFECTION[i] = new Color((int) r, (int) g, (int) b);
		}
	}

	int						colorIndex				= 0;

	public ShapesAnimation1()
	{
		this.setSize(frameSize, frameSize);
		ourContentPane.setDoubleBuffered(true);
		ourContentPane.setBackground(Color.white);
		this.setContentPane(ourContentPane);

		int translation = frameSize / 4;

		square = new Rectangle2D.Double(translation, translation, squareSize,
				squareSize);
		int origin = translation;
		int farCorner = translation + squareSize;

		gradient = new GradientPaint(origin, origin, REFLECTION_COLOR, farCorner,
				farCorner, RICH_BLUE, false);

		// stop the animation timer, if necessary, on window closing event
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				stop();
				if (!isApplet)
				{
					dispose(); // release native resources used by Window & kids
					System.exit(0); // stop the JVM
				}
			}
		});
	}

	public void paint(Graphics g)
	{
		if (init)
		{
			init = false;
			int currentHeight = getHeight();
			insets = getInsets();

			System.out.println("currentHeight=" + currentHeight);
			setSize(frameSize + insets.left + insets.right, frameSize + insets.top
					+ insets.bottom);

			System.out.println("isDoubleBuffered() = "
					+ getContentPane().isDoubleBuffered());

			// ourContentPane.setSize(new Dimension(frameSize, frameSize));
			ourContentPane.setLayout(null);
			ourContentPane
					.setBounds(insets.left, insets.top, frameSize, frameSize);
			ourContentPane.repaint();
		}
		else
			super.paint(g);
	}

	JComponent	ourContentPane	= new JComponent()
										{
											public void update(Graphics g)
											{
												paint(g);
											}

											public void paint(Graphics g)
											{
												super.paint(g);
												System.out.println("hi " + getBounds());

												Graphics2D g2 = (Graphics2D) g;
												// save the parent space
												AffineTransform parentSpace = g2
														.getTransform();

												// account for insets (e.g., title bar &
												// other borders)
												g2.translate(insets.left, insets.top);

												g2.setPaint(REFLECTION_COLOR);
												g2.fill(square);
												g2.setColor(RICH_BLUE);
												g2.setStroke(stroke);
												g2.draw(square);

												double moveOver = square.getWidth() * 1.5;
												g2.translate(moveOver, 0);

												g2.setPaint(gradient);
												g2.fill(square);

												// move down
												g2.translate(0, moveOver);

												Color thisColor = BLUE_TO_RELFECTION[colorIndex];
												g2.setPaint(thisColor);
												g2.fill(square);

												// restore parent space
												g2.setTransform(parentSpace);
											}
										};

	/**
	 * Start the animation loop.
	 */
	public void start()
	{
		if (swingTimer == null)
		{
			swingTimer = new javax.swing.Timer(30, this);
			swingTimer.start();
		}
	}

	/**
	 * End the animation loop.
	 */
	public void stop()
	{
		if (swingTimer != null)
		{
			swingTimer.stop();
			swingTimer = null;
			System.out.println("Timer is stopped.");
		}
	}

	/**
	 * This method is the animation loop. Change the rotations on each SpaceShip
	 * by similar amounts.
	 */
	public void actionPerformed(ActionEvent arg0)
	{
		// called every 30 milliseconds
		int colorIndex = this.colorIndex;
		colorIndex = (colorIndex + sign * 1);
		int animLength = BLUE_TO_RELFECTION.length;
		if (colorIndex >= animLength)
		{
			colorIndex = animLength - 1;
			sign = -1;
		}
		else if (colorIndex < 0)
		{
			colorIndex = 0;
			sign = 1;
		}
		this.colorIndex = colorIndex;

		ourContentPane.repaint();
	}

	public static void main(String[] args)
	{
		ShapesAnimation1 shapesAnimation = new ShapesAnimation1();
		shapesAnimation.setVisible(true);
		shapesAnimation.repaint();
		// shapesAnimation.start();
	}
}
