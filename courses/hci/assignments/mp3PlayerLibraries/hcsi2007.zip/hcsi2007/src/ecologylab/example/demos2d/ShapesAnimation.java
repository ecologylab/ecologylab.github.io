package ecologylab.example.demos2d;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

import javax.swing.JComponent;
import javax.swing.JFrame;

/**
 * Draw shapes, strokes, and fills.
 * 
 * @author andruid
 */
public class ShapesAnimation extends JFrame implements ActionListener
{
	// GUI state
	final int				frameSize			= 500;

	Insets					insets;

	int						squareSize			= frameSize / 6;

	int						spacing				= squareSize / 2;

	/**
	 * Width and height of the area we're drawing in.
	 */
	int						ourSize				= spacing + 2 * squareSize;

	// program state
	boolean					init					= true;

	boolean					isApplet				= false;

	/**
	 * Runs the animation loop in a thread-safe way.
	 */
	javax.swing.Timer		swingTimer;

	ArrayList				shapeCollection	= new ArrayList();

	static final Color	RICH_BLUE			= new Color(35, 0, 92);

	static final Color	LEAFY_GREEN			= new Color(131, 250, 128);

	public ShapesAnimation()
	{
		this.setSize(frameSize, frameSize);
		ourContentPane.setDoubleBuffered(true);
		ourContentPane.setPreferredSize(new Dimension(frameSize, frameSize));
		ourContentPane.setBackground(Color.white);
		this.setContentPane(ourContentPane);

		Shape square = new Rectangle2D.Double(0, 0, squareSize, squareSize);
		AnimatedShape temporalSquare1 = new TemporalGradientShape(square,
				RICH_BLUE, LEAFY_GREEN, 150, 0, 0);

		addAnimatedShape(temporalSquare1);

		int shifted = 3 * squareSize / 2;

		Shape circle = new Ellipse2D.Double(0, 0, squareSize, squareSize);
		TemporalGradientShape temporalCircle1 = addTemporalGradientShape(circle,
				RICH_BLUE, LEAFY_GREEN, 100, shifted, 0);
		temporalCircle1.setTemporalPosition(.666666666666);

		TemporalGradientShape temporalCircle2 = addTemporalGradientShape(circle,
				75, 0, shifted);
		temporalCircle2.setTemporalPosition(.333333333333);

		TemporalGradientShape temporalSquare2 = addTemporalGradientShape(square,
				100, shifted, shifted);
		temporalSquare2.setTemporalPosition(1);

		// stop the animation timer, if necessary, on window closing event
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				stop();
				if (!isApplet)
				{
					dispose(); // release native resources used by Window & kids
					System.exit(0); // stop the JVM
				}
			}
		});
	}

	public boolean addAnimatedShape(AnimatedShape temporalGradient1)
	{
		return shapeCollection.add(temporalGradient1);
	}

	public TemporalGradientShape addTemporalGradientShape(Shape shape,
			Color startColor, Color endColor, int numColors, double x, double y)
	{
		TemporalGradientShape tgs = new TemporalGradientShape(shape, startColor,
				endColor, numColors, x, y);
		addAnimatedShape(tgs);

		return tgs;
	}

	/**
	 * Create a RICH_BLUE to LEAFY_GREEN animated shape with 150 ColorTable steps
	 * (5 seconds), and add it to the animatedShapes collection.
	 * 
	 * @param shape
	 *           Shape to add.
	 * @param x
	 *           Initial x position.
	 * @param y
	 *           Initialyx position.
	 * @return
	 */
	public TemporalGradientShape addTemporalGradientShape(Shape shape,
			int numFrames, double x, double y)
	{
		return addTemporalGradientShape(shape, RICH_BLUE, LEAFY_GREEN, numFrames,
				x, y);
	}

	JComponent	ourContentPane	= new JComponent()
										{
											/*
											 * public void update(Graphics g) { paint(g); }
											 */
											public void paint(Graphics g)
											{
												Graphics2D g2 = (Graphics2D) g;
												// translate to center it
												int xDisplacement = (this.getWidth() - ourSize) / 2;
												int yDisplacement = (this.getHeight() - ourSize) / 2;
												g2.translate(xDisplacement, yDisplacement);

												// save our coordinate space space
												AffineTransform parentSpace = g2
														.getTransform();

												int numShapes = shapeCollection.size();
												for (int i = 0; i < numShapes; i++)
												{
													AnimatedShape thatShape = (AnimatedShape) shapeCollection
															.get(i);
													thatShape.paint(g2);
													g2.setTransform(parentSpace);
												}
											}
										};

	/**
	 * Start the animation loop.
	 */
	public void start()
	{
		if (swingTimer == null)
		{
			swingTimer = new javax.swing.Timer(30, this);
			swingTimer.start();
		}
	}

	/**
	 * End the animation loop.
	 */
	public void stop()
	{
		if (swingTimer != null)
		{
			swingTimer.stop();
			swingTimer = null;
			System.out.println("Timer is stopped.");
		}
	}

	/**
	 * This method is the animation loop. Change the rotations on each SpaceShip
	 * by similar amounts.
	 */
	public void actionPerformed(ActionEvent arg0)
	{
		// called every 30 milliseconds
		int numShapes = shapeCollection.size();

		for (int i = 0; i < numShapes; i++)
		{
			AnimatedShape thatShape = (AnimatedShape) shapeCollection.get(i);
			thatShape.nextFrame();
		}
		ourContentPane.repaint();
	}

	public static void main(String[] args)
	{
		ShapesAnimation shapesAnimation = new ShapesAnimation();
		shapesAnimation.setVisible(true);
		shapesAnimation.repaint();
		shapesAnimation.start();
	}
}
