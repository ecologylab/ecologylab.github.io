package ecologylab.example.demos2d;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.AffineTransform;

import javax.swing.JFrame;

/**
 * Animate a couple of SpaceShips.
 * 
 * @author dcaruso, andruid
 */
public class SpaceShipDemo extends JFrame implements ActionListener
{
	// graphical objects
	SpaceShip				spaceShip1;

	SpaceShip				spaceShip2;

	// GUI state
	final int				frameSize			= 300;

	Insets					insets;

	// program state
	boolean					init					= true;

	boolean					isApplet				= false;

	/**
	 * Runs the animation loop in a thread-safe way.
	 */
	javax.swing.Timer		swingTimer;

	// rendering colors
	static final Color	RICH_BLUE			= new Color(35, 61, 92);

	static final Color	REFLECTION_COLOR	= new Color(131, 192, 128);

	public SpaceShipDemo()
	{
		this.setSize(frameSize, frameSize);
		this.setBackground(Color.white);

		int translation = frameSize / 2;
		int shipSize = frameSize / 3;

		spaceShip1 = new SpaceShip(translation, translation, shipSize, shipSize,
				135.0, RICH_BLUE);
		spaceShip2 = new SpaceShip(translation, translation, shipSize, shipSize,
				315.0, REFLECTION_COLOR);

		// stop the animation timer, if necessary, on window closing event
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				stop();
				if (!isApplet)
				{
					dispose(); // release native resources used by Window & kids
					System.exit(0); // stop the JVM
				}
			}
		});
	}

	public void update(Graphics g)
	{
		paint(g);
	}

	public void paint(Graphics g)
	{
		super.paint(g);
		if (init)
		{
			init = false;
			int currentHeight = getHeight();
			insets = getInsets();

			this.getContentPane().setBackground(Color.white);

			System.out.println("currentHeight=" + currentHeight);
			setSize(frameSize + insets.left + insets.right, frameSize + insets.top
					+ insets.bottom);

			repaint();
		}
		else
		{
			Graphics2D g2 = (Graphics2D) g;
			// save the parent space
			AffineTransform parentSpace = g2.getTransform();

			// center amidst insets (e.g., title bar & other borders)
			g2.translate(insets.left, insets.top);
			spaceShip1.paint(g2);
			spaceShip2.paint(g2);
			// restore parent space
			g2.setTransform(parentSpace);
		}
	}

	/**
	 * Start the animation loop.
	 */
	public void start()
	{
		if (swingTimer == null)
		{
			swingTimer = new javax.swing.Timer(30, this);
			swingTimer.start();
		}
	}

	/**
	 * End the animation loop.
	 */
	public void stop()
	{
		if (swingTimer != null)
		{
			swingTimer.stop();
			swingTimer = null;
			System.out.println("Timer is stopped.");
		}
	}

	/**
	 * This method is the animation loop. Change the rotations on each SpaceShip
	 * by similar amounts.
	 */
	public void actionPerformed(ActionEvent arg0)
	{
		// called every 30 milliseconds
		spaceShip1.incrementHeading(1.0);
		spaceShip2.incrementHeading(.99);
		repaint();
	}

	public static void main(String[] args)
	{
		SpaceShipDemo spaceDemo = new SpaceShipDemo();
		spaceDemo.setVisible(true);
		spaceDemo.repaint();
		spaceDemo.start();
	}
}
