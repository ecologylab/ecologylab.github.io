package ecologylab.media;

import java.util.ArrayList;

public interface SyncFinder
{
	public int findSyncFrame(AudioBufferPlayer p, int syncChannel);	
}
