/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <device.h>

void main()
{

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
	uint8 usb_data = 0;
    CyGlobalIntEnable; /* Uncomment this line to enable global interrupts. */
	USBFS_1_Start(0,USBFS_1_3V_OPERATION);
	while(!USBFS_1_GetConfiguration());
    for(;;)
    {
		usb_data = 0;
		while(USBFS_1_GetEPState(1) != USBFS_1_IN_BUFFER_EMPTY);
		USBFS_1_LoadInEP(1, &usb_data, 1);
		usb_data = 255;
		while(USBFS_1_GetEPState(1) != USBFS_1_IN_BUFFER_EMPTY);
		USBFS_1_LoadInEP(1, &usb_data, 1);
		
		
        /* Place your application code here. */
    }
}

/* [] END OF FILE */
